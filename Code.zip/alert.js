let x= "Give me a ";
let y= "100!!";
const string = x + y;
alert(string);